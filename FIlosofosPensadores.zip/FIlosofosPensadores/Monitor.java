package FIlosofosPensadores;

import java.util.logging.Level;
import java.util.logging.Logger;

public class Monitor { // Es el monitor del programa y sera el encargado de tomar o liberar los tenedores
    
    private boolean[] tenedores; //Creamos un arreglo donde guardaremos los tenedores en V o F 
    
    public Monitor(int numTenedores){ // Le pasamos el numero de tenedores declarados en principal
        this.tenedores = new boolean[numTenedores];
    }
    
    public int tenedorIzquierda(int i){ // Si sera el filosofo, si toma el tenedor izquierdo sera igual a su indice
        return i;
    }
    
    public int tenedorDerecha(int i){ // Si toma derecha se decrementara
        if(i == 0){
            return this.tenedores.length - 1; //Esto es una cola circular en el que primero filosofo tiene que tomar el tenedor de su izquierda osea el ultimo
        }else{
            return i - 1;
        }
    }
    
    public synchronized void tomarTenedores(int nfilosofo){
        
        while(tenedores[tenedorIzquierda(nfilosofo)] || tenedores[tenedorDerecha(nfilosofo)]){
            try {  
            System.out.println("Filosofo " + (nfilosofo+1) + " quiere comer pero no puede porque estan ocupando uno de sus tenedores"); 
                wait(); //Esto se encargara de comprobar si los tenemos <- o -> estan ocupados, si lo estan se bloquea con la funcion wait


            } catch (InterruptedException ex) {
                Logger.getLogger(Mesa.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        tenedores[tenedorIzquierda(nfilosofo)] = true; // si no estan ocupados los asignamos con un true diciendo que estan ocupados
        tenedores[tenedorDerecha(nfilosofo)] = true;
    }
    
    public synchronized void dejarTenedores(int nfilosofo){ // cuando termine de usarlos los liberamos con un false indicando que estan disponibles
        tenedores[tenedorIzquierda(nfilosofo)] = false;
        tenedores[tenedorDerecha(nfilosofo)] = false;
        notifyAll(); //Hace una llamada a los procesos que inicien la funcion de comprobacion
    }
    
}
