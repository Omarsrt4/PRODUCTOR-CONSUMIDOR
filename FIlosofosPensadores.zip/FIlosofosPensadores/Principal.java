package FIlosofosPensadores;

public class Principal {
    
    public static void main(String[] args) {
        Monitor m = new Monitor(5); //creamos la mesa con sus 5 filosofos
        for (int i = 1; i <= 5; i++) {
            Filosofo f = new Filosofo(m, i);
            f.start();
        }
    }
}
