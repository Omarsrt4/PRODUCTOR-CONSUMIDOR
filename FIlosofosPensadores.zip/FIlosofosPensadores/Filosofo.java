package FIlosofosPensadores;

import java.util.logging.Level;
import java.util.logging.Logger;

public class Filosofo extends Thread {
    
    private Monitor monitor; //Gestiona el uso de tenedores
    private int nfilosofo; //numero de filosofo
    private int indiceTenedor;  //numero de tenedor
    
    public Filosofo(Monitor m, int nfilosofo){
        this.monitor = m;
        this.nfilosofo = nfilosofo;
       this.indiceTenedor = nfilosofo-1;
       
       
        
        
        
        
        
    }
    
    public void run(){ //Esta funcion se encargara de recibir los datos de herencia 
        
        while(true){
            this.pensando();
            this.monitor.tomarTenedores(this.indiceTenedor); //Una vez que puede comer, toma los tenedores
            this.comiendo();
            System.out.println("Filosofo " + nfilosofo +  " deja de comer y libera los tenedores" + (this.monitor.tenedorIzquierda(this.indiceTenedor) + 1) + ", " + (this.monitor.tenedorDerecha(this.indiceTenedor) + 1) );
            this.monitor.dejarTenedores(this.indiceTenedor);
        }
        
    }
    
    public void pensando(){
       
        System.out.println("Filosofo " + nfilosofo + " esta pensando en los S.O");
        try {
            sleep((long) (Math.random() * 4000)); //Funciona que determinara el tiempo que se la pasa pensando 
        } catch (InterruptedException ex) { }
        
    }
    
    public void comiendo(){
        System.out.println("Filosofo " + nfilosofo + " se estresa y mejor se pone a comer");//Funciona que determinara el tiempo que se la pasa comiendo
         
   System.out.println("Filosofo " + nfilosofo +  " toma los tenedores " + (this.monitor.tenedorIzquierda(this.indiceTenedor) + 1) + ", " + (this.monitor.tenedorDerecha(this.indiceTenedor) + 1) );  
       
        try {
            sleep((long) (Math.random() * 4000));
        } catch (InterruptedException ex) { }
    }
    
}
